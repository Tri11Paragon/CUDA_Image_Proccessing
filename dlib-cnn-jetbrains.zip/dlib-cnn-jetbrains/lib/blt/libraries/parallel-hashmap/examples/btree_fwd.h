#include <string>

#include <parallel_hashmap/phmap_fwd_decl.h>

using IntString = phmap::btree_map<int, std::string>;

