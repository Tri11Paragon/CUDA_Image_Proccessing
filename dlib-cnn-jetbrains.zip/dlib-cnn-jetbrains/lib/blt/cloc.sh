cloc --exclude-list-file=exclude.txt include src
