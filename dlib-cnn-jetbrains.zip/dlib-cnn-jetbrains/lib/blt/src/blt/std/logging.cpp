/*
 * Created by Brett on 20/07/23.
 * Licensed under GNU General Public License V3.0
 * See LICENSE file for license detail
 */
#define BLT_LOGGING_IMPLEMENTATION
#include <blt/std/logging.h>
