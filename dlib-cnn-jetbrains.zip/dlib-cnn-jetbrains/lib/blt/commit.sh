#!/bin/bash
git add *
git commit
git push -u github main
git push -u tpgc main
