rm -fr debug release debug-addr reldebug-addr clang-debug clang-release clang-debug-addr clang-reldebug-addr
