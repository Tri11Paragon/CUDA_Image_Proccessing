/*
 * Created by Brett on 31/03/23.
 * Licensed under GNU General Public License V3.0
 * See LICENSE file for license detail
 */

#ifndef BLT_TESTS_HASHMAP_TEXTS_H
#define BLT_TESTS_HASHMAP_TEXTS_H

#include <blt/std/hashmap.h>

inline static int test_hashmaps(){
    
    
    return 0;
}

#endif //BLT_TESTS_HASHMAP_TEXTS_H
